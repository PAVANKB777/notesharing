import { Router } from 'express';
import { queryAll, queryGet, run } from '../utils/db.js';
import { authRequired } from '../utils/auth.js';

const router = Router();

// Public notes (no auth)
router.get('/public', (req, res) => {
  const rows = queryAll('SELECT notes.id, title, content, isPublic, user_id, users.name as author FROM notes JOIN users ON users.id = notes.user_id WHERE isPublic = 1 ORDER BY notes.id DESC');
  res.json(rows);
});

// All my notes
router.get('/', authRequired, (req, res) => {
  const rows = queryAll('SELECT * FROM notes WHERE user_id = ? ORDER BY id DESC', [req.user.id]);
  res.json(rows);
});

router.post('/', authRequired, (req, res) => {
  const { title, content, isPublic } = req.body || {};
  if (!title || !content) return res.status(400).json({ error: 'Title and content required' });
  const info = run('INSERT INTO notes(title, content, isPublic, user_id) VALUES(?,?,?,?)', [title, content, isPublic ? 1 : 0, req.user.id]);
  const row = queryGet('SELECT * FROM notes WHERE id = ?', [info.lastInsertRowid]);
  res.status(201).json(row);
});

router.put('/:id', authRequired, (req, res) => {
  const { id } = req.params;
  const { title, content, isPublic } = req.body || {};
  const existing = queryGet('SELECT * FROM notes WHERE id = ? AND user_id = ?', [id, req.user.id]);
  if (!existing) return res.status(404).json({ error: 'Note not found' });
  const t = title ?? existing.title;
  const c = content ?? existing.content;
  const p = (isPublic === undefined ? existing.isPublic : (isPublic ? 1 : 0));
  run('UPDATE notes SET title = ?, content = ?, isPublic = ? WHERE id = ?', [t, c, p, id]);
  const row = queryGet('SELECT * FROM notes WHERE id = ?', [id]);
  res.json(row);
});

router.delete('/:id', authRequired, (req, res) => {
  const { id } = req.params;
  const existing = queryGet('SELECT * FROM notes WHERE id = ? AND user_id = ?', [id, req.user.id]);
  if (!existing) return res.status(404).json({ error: 'Note not found' });
  run('DELETE FROM notes WHERE id = ?', [id]);
  res.json({ ok: true });
});

export default router;
