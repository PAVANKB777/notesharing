import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import authRoutes from './routes/authRoutes.js';
import noteRoutes from './routes/noteRoutes.js';
import { ensureDb } from './utils/db.js';
import { seedDemo } from './utils/seed.js';

dotenv.config();
const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors({ origin: process.env.CORS_ORIGIN?.split(',') || '*', credentials: true }));
app.use(express.json());

await ensureDb();
console.log('Initializing database...');
seedDemo();
console.log('Seeding demo user complete');

app.get('/', (req,res) => res.json({ ok: true, service: 'Notes Sharing API' }));
app.use('/api/auth', authRoutes);
app.use('/api/notes', noteRoutes);

app.listen(PORT, () => console.log(`API running on http://localhost:${PORT}`));
