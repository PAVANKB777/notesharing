import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs from 'sql.js';
import dotenv from 'dotenv';
dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const dbFile = process.env.DATABASE_FILE || './data.sqlite';

let SQL = null;
let db = null;

function saveDb(){
  const data = db.export();
  fs.writeFileSync(dbFile, Buffer.from(data));
}

export async function ensureDb(){
  if(!SQL){
    const distDir = path.resolve(__dirname, '../node_modules/sql.js/dist');
  SQL = await initSqlJs({ locateFile: file => path.join(distDir, file) });
  }
  if(fs.existsSync(dbFile)){
    const filebuf = fs.readFileSync(dbFile);
    db = new SQL.Database(new Uint8Array(filebuf));
  }else{
    db = new SQL.Database();
  }
  // Create schema
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS notes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      content TEXT NOT NULL,
      isPublic INTEGER NOT NULL DEFAULT 0,
      user_id INTEGER NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );
  `);
  saveDb();
}

// Helper query functions
export function queryAll(sql, params=[]){
  const stmt = db.prepare(sql);
  stmt.bind(params);
  const rows = [];
  while(stmt.step()){
    rows.push(stmt.getAsObject());
  }
  stmt.free();
  return rows;
}

export function queryGet(sql, params=[]){
  const rows = queryAll(sql, params);
  return rows[0];
}

export function run(sql, params=[]){
  const stmt = db.prepare(sql);
  stmt.bind(params);
  stmt.step();
  stmt.free();
  // emulate last insert id
  const r = queryGet('SELECT last_insert_rowid() as id');
  saveDb();
  return { lastInsertRowid: r?.id };
}
