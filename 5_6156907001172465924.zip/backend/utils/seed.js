import bcrypt from 'bcryptjs';
import { queryGet, run } from './db.js';

export function seedDemo() {
  if (String(process.env.SEED_DEMO || 'true').toLowerCase() === 'false') return;
  const name = process.env.DEMO_NAME || 'Demo';
  const email = process.env.DEMO_EMAIL || 'demo@notes.app';
  const password = process.env.DEMO_PASSWORD || 'Pass@123';

  const existing = queryGet('SELECT id FROM users WHERE email = ?', [email]);
  if (!existing) {
    const hash = bcrypt.hashSync(password, 10);
    run('INSERT INTO users(name,email,password) VALUES(?,?,?)', [name, email, hash]);
    console.log(`Seeded demo user -> ${email} / ${password}`);
  }
}
