# Notes Sharing App (No-Native Build Backend)

This build uses **sql.js (WASM)** instead of native SQLite bindings. That means:
- ✅ **No node-gyp / Visual Studio build tools required**
- ✅ Works on Node 18/20/22 on Windows/Mac/Linux

## Run

### Backend
```bash
cd backend
cp .env.example .env
npm install
npm run dev   # API http://localhost:4000
```
> A demo user is auto-seeded on startup:
> - Email: demo@notes.app
> - Password: Pass@123

### Frontend
```bash
cd ../frontend
npm install
echo VITE_API_URL=http://localhost:4000 > .env
npm run dev   # UI http://localhost:5173
```

## API
- POST `/api/auth/signup` `{name,email,password}`
- POST `/api/auth/login` `{email,password}` -> `{user, token}`
- GET `/api/notes/public`
- GET `/api/notes` *(auth)*
- POST `/api/notes` *(auth)* `{title,content,isPublic}`
- PUT `/api/notes/:id` *(auth)*
- DELETE `/api/notes/:id` *(auth)*
