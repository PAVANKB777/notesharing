// intentionally left minimal; using CSS utility classes in index.css
export default function Button({className='', ...props}){ return <button className={`btn btn-primary ${className}`} {...props} /> }
