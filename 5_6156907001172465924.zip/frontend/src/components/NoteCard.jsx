export default function NoteCard({note, onEdit, onDelete}){
  return (
    <div className="card">
      <div className="flex items-start justify-between gap-2">
        <h3 className="text-lg font-semibold">{note.title}</h3>
        {onEdit && (
          <div className="flex gap-2">
            <button className="btn btn-outline text-sm" onClick={onEdit}>Edit</button>
            <button className="btn btn-outline text-sm" onClick={onDelete}>Delete</button>
          </div>
        )}
      </div>
      <p className="mt-2 whitespace-pre-wrap">{note.content}</p>
      <div className="mt-3 text-xs text-muted">{note.isPublic ? 'Public' : 'Private'}</div>
    </div>
  )
}
