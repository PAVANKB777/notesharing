import { Link, useNavigate } from 'react-router-dom'
import { useSelector, useDispatch } from 'react-redux'
import { logout } from '../features/authSlice'

export default function Navbar(){
  const auth = useSelector(s=>s.auth)
  const dispatch = useDispatch()
  const nav = useNavigate()
  const onLogout = ()=>{ dispatch(logout()); nav('/login') }
  return (
    <nav className="nav">
      <div className="flex items-center gap-3">
        <div className="h-8 w-8 rounded-2xl bg-primary" />
        <Link className="font-semibold" to="/public">Notes Sharing</Link>
      </div>
      <div className="flex items-center gap-3">
        <Link className="link" to="/public">Public</Link>
        {auth.user && <Link className="link" to="/dashboard">Dashboard</Link>}
        {!auth.user ? <Link className="btn btn-primary" to="/login">Login</Link> :
          <button className="btn btn-outline" onClick={onLogout}>Logout</button>}
      </div>
    </nav>
  )
}
