import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import api from '../api'
import { useDispatch } from 'react-redux'
import { setCredentials } from '../features/authSlice'

export default function Signup(){
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState(null)
  const dispatch = useDispatch()
  const nav = useNavigate()

  const submit = async (e)=>{
    e.preventDefault()
    setError(null)
    try{
      const { data } = await api.post('/auth/signup', { name, email, password })
      dispatch(setCredentials(data))
      nav('/dashboard')
    }catch(err){
      setError(err?.response?.data?.error || 'Signup failed')
    }
  }

  return (
    <div className="max-w-md mx-auto mt-10">
      <div className="card">
        <h1 className="text-2xl font-bold">Create your account</h1>
        <p className="text-muted">Start taking and sharing notes.</p>
        <form onSubmit={submit} className="mt-6 space-y-3">
          <div>
            <label className="label">Name</label>
            <input className="input" value={name} onChange={e=>setName(e.target.value)} required />
          </div>
          <div>
            <label className="label">Email</label>
            <input className="input" type="email" value={email} onChange={e=>setEmail(e.target.value)} required />
          </div>
          <div>
            <label className="label">Password</label>
            <input className="input" type="password" value={password} onChange={e=>setPassword(e.target.value)} required />
          </div>
          {error && <div className="text-red-400 text-sm">{error}</div>}
          <button className="btn btn-primary w-full" type="submit">Sign up</button>
        </form>
        <div className="mt-4 text-sm">Have an account? <Link className="link" to="/login">Log in</Link></div>
      </div>
    </div>
  )
}
