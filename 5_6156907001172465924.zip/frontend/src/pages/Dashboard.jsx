import { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { fetchMyNotes, createNote, updateNote, deleteNote } from '../features/notesSlice'
import NoteCard from '../components/NoteCard'

export default function Dashboard(){
  const dispatch = useDispatch()
  const { my } = useSelector(s=>s.notes)
  const [title, setTitle] = useState('')
  const [content, setContent] = useState('')
  const [isPublic, setIsPublic] = useState(false)
  const [editing, setEditing] = useState(null)

  useEffect(()=>{ dispatch(fetchMyNotes()) }, [dispatch])

  const submit = (e)=>{
    e.preventDefault()
    if(editing){
      dispatch(updateNote({ id: editing.id, data: { title, content, isPublic } }))
      setEditing(null)
    }else{
      dispatch(createNote({ title, content, isPublic }))
    }
    setTitle(''); setContent(''); setIsPublic(false)
  }

  const onEdit = (n)=>{ setEditing(n); setTitle(n.title); setContent(n.content); setIsPublic(!!n.isPublic) }

  return (
    <div className="space-y-6">
      <div className="card">
        <h2 className="text-xl font-semibold">{editing ? 'Edit note' : 'New note'}</h2>
        <form onSubmit={submit} className="mt-3 grid gap-3">
          <input className="input" placeholder="Title" value={title} onChange={e=>setTitle(e.target.value)} required />
          <textarea className="input min-h-[120px]" placeholder="Content" value={content} onChange={e=>setContent(e.target.value)} required />
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={isPublic} onChange={e=>setIsPublic(e.target.checked)} />
            Make public
          </label>
          <div className="flex gap-2">
            <button className="btn btn-primary" type="submit">{editing ? 'Update' : 'Create'}</button>
            {editing && <button type="button" className="btn btn-outline" onClick={()=>{setEditing(null); setTitle(''); setContent(''); setIsPublic(false)}}>Cancel</button>}
          </div>
        </form>
      </div>

      <div>
        <h2 className="text-xl font-semibold mb-3">My notes</h2>
        <div className="grid-notes">
          {my.map(n=>(
            <NoteCard key={n.id} note={n} onEdit={()=>onEdit(n)} onDelete={()=>dispatch(deleteNote(n.id))} />
          ))}
        </div>
      </div>
    </div>
  )
}
