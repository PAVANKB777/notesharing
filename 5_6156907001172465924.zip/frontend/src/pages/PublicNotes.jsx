import { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { fetchPublicNotes } from '../features/notesSlice'
import NoteCard from '../components/NoteCard'
import { Link } from 'react-router-dom'

export default function PublicNotes(){
  const dispatch = useDispatch()
  const { public: list } = useSelector(s=>s.notes)
  const { user } = useSelector(s=>s.auth)

  useEffect(()=>{ dispatch(fetchPublicNotes()) }, [dispatch])

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Public notes</h1>
        {user ? <Link className="btn btn-primary" to="/dashboard">New note</Link> : <Link className="btn btn-outline" to="/login">Login</Link>}
      </div>
      <div className="grid-notes">
        {list.map(n=>(<NoteCard key={n.id} note={n} />))}
      </div>
    </div>
  )
}
