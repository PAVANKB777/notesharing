import React from 'react'
import ReactDOM from 'react-dom/client'
import { Provider } from 'react-redux'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import './index.css'
import store from './store'
import App from './App'
import Login from './pages/Login'
import Signup from './pages/Signup'
import Dashboard from './pages/Dashboard'
import PublicNotes from './pages/PublicNotes'

const Root = () => (
  <Provider store={store}>
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<App/>}>
          <Route index element={<Navigate to="/public" replace/>} />
          <Route path="login" element={<Login/>} />
          <Route path="signup" element={<Signup/>} />
          <Route path="dashboard" element={<Dashboard/>} />
          <Route path="public" element={<PublicNotes/>} />
        </Route>
      </Routes>
    </BrowserRouter>
  </Provider>
)

ReactDOM.createRoot(document.getElementById('root')).render(<Root/>)
