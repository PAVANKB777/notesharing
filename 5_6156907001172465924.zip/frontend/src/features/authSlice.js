import { createSlice } from '@reduxjs/toolkit'

const saved = localStorage.getItem('auth')
const initial = saved ? JSON.parse(saved) : { user: null, token: null }

const slice = createSlice({
  name: 'auth',
  initialState: initial,
  reducers: {
    setCredentials(state, action){
      state.user = action.payload.user
      state.token = action.payload.token
      localStorage.setItem('auth', JSON.stringify(state))
      localStorage.setItem('token', action.payload.token)
    },
    logout(state){
      state.user = null
      state.token = null
      localStorage.removeItem('auth')
      localStorage.removeItem('token')
    }
  }
})

export const { setCredentials, logout } = slice.actions
export default slice.reducer
