import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import api from '../api'

export const fetchMyNotes = createAsyncThunk('notes/fetchMy', async () => (await api.get('/notes')).data)
export const fetchPublicNotes = createAsyncThunk('notes/fetchPublic', async () => (await api.get('/notes/public')).data)
export const createNote = createAsyncThunk('notes/create', async (note) => (await api.post('/notes', note)).data)
export const updateNote = createAsyncThunk('notes/update', async ({id, data}) => (await api.put(`/notes/${id}`, data)).data)
export const deleteNote = createAsyncThunk('notes/delete', async (id) => { await api.delete(`/notes/${id}`); return id })

const slice = createSlice({
  name: 'notes',
  initialState: { my: [], public: [], status: 'idle', error: null },
  reducers: {},
  extraReducers: (b) => {
    b.addCase(fetchMyNotes.fulfilled, (s,a)=>{ s.my = a.payload })
     .addCase(fetchPublicNotes.fulfilled, (s,a)=>{ s.public = a.payload })
     .addCase(createNote.fulfilled, (s,a)=>{ s.my.unshift(a.payload) })
     .addCase(updateNote.fulfilled, (s,a)=>{
        const i = s.my.findIndex(n=>n.id===a.payload.id); if(i>-1) s.my[i]=a.payload
     })
     .addCase(deleteNote.fulfilled, (s,a)=>{ s.my = s.my.filter(n=>n.id!==a.payload) })
  }
})

export default slice.reducer
